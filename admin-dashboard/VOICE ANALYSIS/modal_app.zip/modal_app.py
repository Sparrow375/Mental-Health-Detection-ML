"""
modal_app.py  —  Lumen · WavLM Depression-Detection API
=======================================================
Deployment target : Modal.com  (modal.com/docs)
GPU               : NVIDIA T4  (free-tier, ~30 GPU hrs/month)
keep_warm         : 1 container always warm  → zero cold-starts
Model             : WavLM fine-tuned for audio classification
                    hosted on Hugging Face Hub at HF_REPO_ID below

────────────────────────────────────────────────────────────────
SPENDING GUARD — set a $0.00 hard cap in the Modal dashboard:
  Dashboard → Settings → Billing → "Monthly spend limit" → $0.00
  The free-tier allowance ($30/month credit refreshed monthly) is
  applied first; the $0 cap prevents any overage charges.
  One T4 container with keep_warm=1 consumes ≈ 0.08 GPU-hrs/day
  idle, leaving ~27 GPU-hrs for actual inference budget.
────────────────────────────────────────────────────────────────

Deploy:
  pip install modal
  modal token new           # one-time auth
  modal deploy modal_app.py # → prints your HTTPS endpoint URL

Local dev / smoke-test:
  modal serve modal_app.py  # hot-reload on save
"""

# ──────────────────────────────────────────────────────────────
# 0.  CONFIG  — replace with your actual HF repo before deploy
# ──────────────────────────────────────────────────────────────
HF_REPO_ID = "Nitish1018/mhealth-voice-api"       # HF Space repo containing model weights

# WavLM was trained at 16 kHz — DO NOT change this constant.
TARGET_SAMPLE_RATE = 16_000

# Chunk length (seconds) fed to the model.  WavLM context window
# is 30 s max; 10 s chunks give stable results across short clips.
CHUNK_SECONDS = 10

# Depression threshold: model raw probability above this → "Depressed"
DEPRESSION_THRESHOLD = 0.40

# Sub-folder within the HF Space repo where the fine-tuned weights live
MODEL_SUBFOLDER = "wavlm_lora_v10/best_model"

# Overlap between consecutive audio chunks (mirrors HF Space inference)
OVERLAP_SECONDS = 2

# Silence stripping config (mirrors HF Space main.py)
SILENCE_THRESHOLD_DB = -40.0      # dB threshold for active speech detection
MIN_AUDIO_SECONDS    = 3.0        # minimum clip length after silence strip

# ──────────────────────────────────────────────────────────────
# 1.  MODAL IMAGE  — pinned versions for reproducibility
# ──────────────────────────────────────────────────────────────
import modal

image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install(
        "torch==2.3.1",           # CPU wheel used only for audio pre-proc;
        "torchaudio==2.3.1",      # model runs on GPU via .to(device)
        "transformers==4.41.2",
        "librosa==0.10.2",        # robust resampling for any input SR
        "soundfile==0.12.1",      # WAV/FLAC backend for librosa
        "httpx==0.27.0",          # lightweight HTTP (not used in inference path)
        "fastapi[standard]==0.111.0",
        "python-multipart==0.0.9",  # multipart/form-data parsing
        "numpy==1.26.4",
    )
)

app = modal.App(name="lumen-wavlm", image=image)

# ──────────────────────────────────────────────────────────────
# 2.  INFERENCE CLASS
#     @modal.enter() loads model exactly ONCE when the container
#     starts — never reloaded between requests.
# ──────────────────────────────────────────────────────────────
@app.cls(
    gpu="T4",                    # NVIDIA T4 — free-tier eligible
    min_containers=1,            # 1 container always hot → 0 cold-starts
    scaledown_window=300,        # seconds before an idle container is recycled
    timeout=600,                 # max seconds per request
    image=image,
    secrets=[modal.Secret.from_name("huggingface")],
)
class WavLMPredictor:

    @modal.enter()
    def load_model(self) -> None:
        """
        Called ONCE when the container boots.
        Loads the custom WavLMAttentionPool model from the HF Space repo using
        the same architecture and weights as the proven HF Space inference stack.
        The HF_TOKEN secret grants access to the private repo.
        """
        import os
        import torch
        import torch.nn.functional as F
        from torch import nn
        from transformers import Wav2Vec2FeatureExtractor, WavLMForSequenceClassification
        from transformers.modeling_outputs import SequenceClassifierOutput

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        hf_token = os.environ.get("HF_TOKEN")

        # ── Custom model class (must match training code exactly) ─────────────
        class AttentionPooling(nn.Module):
            def __init__(self, hidden_size: int, num_heads: int = 2):
                super().__init__()
                self.num_heads = num_heads
                self.head_dim  = hidden_size // num_heads
                assert hidden_size % num_heads == 0
                self.query      = nn.Parameter(torch.randn(num_heads, 1, self.head_dim) * 0.02)
                self.key_proj   = nn.Linear(hidden_size, hidden_size)
                self.value_proj = nn.Linear(hidden_size, hidden_size)
                self.out_proj   = nn.Linear(hidden_size, hidden_size)
                self.norm       = nn.LayerNorm(hidden_size)

            def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
                B, T, H = hidden_states.shape
                keys   = self.key_proj(hidden_states).view(B, T, self.num_heads, self.head_dim)
                values = self.value_proj(hidden_states).view(B, T, self.num_heads, self.head_dim)
                keys   = keys.permute(0, 2, 1, 3)
                values = values.permute(0, 2, 1, 3)
                attn   = torch.matmul(self.query, keys.transpose(-2, -1)) / (self.head_dim ** 0.5)
                attn   = F.softmax(attn, dim=-1)
                return self.norm(self.out_proj(torch.matmul(attn, values).squeeze(2).reshape(B, H)))

        class WavLMAttentionPool(WavLMForSequenceClassification):
            def __init__(self, config):
                super().__init__(config)
                h = config.hidden_size
                self.attn_pool = AttentionPooling(h, num_heads=2)
                self.cls_drop  = nn.Dropout(0.15)
                self.cls_proj  = nn.Linear(h, 256)
                self.cls_norm  = nn.LayerNorm(256)
                self.cls_out   = nn.Linear(256, config.num_labels)

            def forward(self, input_values, attention_mask=None, labels=None, **kwargs):
                h      = self.wavlm(input_values, attention_mask=attention_mask).last_hidden_state
                pooled = self.attn_pool(h)
                x      = torch.relu(self.cls_proj(self.cls_drop(pooled)))
                return SequenceClassifierOutput(logits=self.cls_out(self.cls_drop(self.cls_norm(x))))

        # ── Load weights from HF Space repo (subfolder = model directory) ─────
        print(f"[Lumen] Loading model from '{HF_REPO_ID}/{MODEL_SUBFOLDER}' onto {self.device} …")
        self.feature_extractor = Wav2Vec2FeatureExtractor.from_pretrained(
            HF_REPO_ID,
            subfolder=MODEL_SUBFOLDER,
            token=hf_token,
        )
        self.model = WavLMAttentionPool.from_pretrained(
            HF_REPO_ID,
            subfolder=MODEL_SUBFOLDER,
            token=hf_token,
            num_labels=2,
            id2label={0: "Not Depressed", 1: "Depressed"},
            label2id={"Not Depressed": 0, "Depressed": 1},
            ignore_mismatched_sizes=True,  # base-class head layers aren't used
        ).to(self.device).eval()
        print("[Lumen] Model ready ✓")

    # ------------------------------------------------------------------
    # Internal helper — audio pipeline
    # ------------------------------------------------------------------
    def _preprocess_audio(self, raw_bytes: bytes, content_type: str) -> "np.ndarray":
        """
        Decode any audio format (WAV, FLAC, MP3, WebM/Opus, M4A, OGG) into
        a float32 mono waveform at TARGET_SAMPLE_RATE.

        Sampling-rate handling strategy
        ────────────────────────────────
        1. Try soundfile (fast, lossless for PCM formats).
        2. Fall back to librosa which shells out to ffmpeg for compressed
           formats (WebM/Opus from browser MediaRecorder, MP3, M4A, etc.).
        librosa.resample uses its high-quality "soxr_hq" resampler when
        available, otherwise falls back to scipy.  Both produce results
        within human-imperceptible tolerance for 16 kHz speech.
        """
        import io
        import numpy as np
        import soundfile as sf
        import librosa

        buf = io.BytesIO(raw_bytes)

        try:
            # Path 1: soundfile (PCM / FLAC)
            waveform, sr = sf.read(buf, dtype="float32", always_2d=False)
            if waveform.ndim == 2:
                waveform = waveform.mean(axis=1)       # stereo → mono
        except Exception:
            # Path 2: librosa (WebM, MP3, M4A, OGG, …)
            buf.seek(0)
            waveform, sr = librosa.load(buf, sr=None, mono=True)

        # Resample to exactly 16 kHz (WavLM requirement — never skip)
        if sr != TARGET_SAMPLE_RATE:
            waveform = librosa.resample(
                waveform,
                orig_sr=sr,
                target_sr=TARGET_SAMPLE_RATE,
                res_type="soxr_hq",   # highest quality; falls back gracefully
            )

        return waveform.astype("float32")

    def _chunk_waveform(self, waveform: "np.ndarray") -> "list[np.ndarray]":
        """Split recording into overlapping chunks — mirrors HF Space main.py."""
        import numpy as np
        chunk_len = CHUNK_SECONDS * TARGET_SAMPLE_RATE
        stride    = (CHUNK_SECONDS - OVERLAP_SECONDS) * TARGET_SAMPLE_RATE
        total     = len(waveform)
        if total < chunk_len:
            return [np.pad(waveform, (0, chunk_len - total))]
        chunks, start = [], 0
        while start < total:
            end   = start + chunk_len
            chunk = waveform[start:end]
            if len(chunk) < chunk_len:
                chunk = np.pad(chunk, (0, chunk_len - len(chunk)))
            chunks.append(chunk)
            start += stride
            if end >= total:
                break
        return chunks

    def _strip_silence(self, waveform: "np.ndarray") -> "np.ndarray":
        """Remove leading/trailing silence — mirrors HF Space main.py."""
        import numpy as np
        threshold = 10 ** (SILENCE_THRESHOLD_DB / 20.0)
        win       = int(TARGET_SAMPLE_RATE * 0.05)   # 50 ms energy windows
        energy    = np.array([
            np.sqrt(np.mean(waveform[i : i + win] ** 2))
            for i in range(0, len(waveform) - win, win)
        ])
        active = energy > threshold
        if not np.any(active):
            return waveform                             # fully silent → keep all
        buf   = int(TARGET_SAMPLE_RATE * 0.2)           # 200 ms boundary padding
        first = int(np.argmax(active)) * win
        last  = (len(active) - 1 - int(np.argmax(active[::-1]))) * win + win
        return waveform[max(0, first - buf) : min(len(waveform), last + buf)]

    # ------------------------------------------------------------------
    # Public method — called by the web endpoint
    # ------------------------------------------------------------------
    @modal.method()
    def predict(self, audio_bytes: bytes, content_type: str = "audio/wav") -> dict:
        """
        Inference pipeline mirrors HF Space main.py exactly:
          decode → strip silence → z-score normalise → overlapping chunks
          → GPU batch inference → confidence-weighted pooling → JSON response
        """
        import time
        import numpy as np
        import torch

        t0 = time.perf_counter()

        # 1. Decode audio to float32 mono waveform at 16 kHz
        waveform = self._preprocess_audio(audio_bytes, content_type)

        # 2. Strip silence; fall back to original if result is too short
        stripped = self._strip_silence(waveform)
        if len(stripped) / TARGET_SAMPLE_RATE >= MIN_AUDIO_SECONDS:
            waveform = stripped

        # 3. Z-score normalise (feature extractor has do_normalize=false)
        std = float(np.std(waveform))
        if std > 1e-8:
            waveform = (waveform - float(np.mean(waveform))) / std

        # 4. Split into overlapping chunks (all same length → no padding needed)
        chunks = self._chunk_waveform(waveform)

        # 5. Encode + single GPU batch pass
        inputs = self.feature_extractor(
            chunks,
            sampling_rate=TARGET_SAMPLE_RATE,
            return_tensors="pt",
            padding=True,              # same-length chunks → no padding added
        )
        inputs = {k: v.to(self.device) for k, v in inputs.items()}

        with torch.inference_mode():
            logits = self.model(**inputs).logits               # (N_chunks, 2)
            probs  = torch.softmax(logits, dim=-1).cpu().numpy()  # (N_chunks, 2)

        # 6. Confidence-weighted pooling — mirrors main.py exactly
        #    final = 0.5 * mean_dep + 0.5 * confidence_weighted_dep
        mean_dep = float(probs.mean(axis=0)[1])
        confs    = np.max(probs, axis=1)
        w_dep    = (
            float((probs.T * confs).T.sum(axis=0)[1] / confs.sum())
            if confs.sum() > 0 else mean_dep
        )
        depression_prob = 0.5 * mean_dep + 0.5 * w_dep

        is_depressed = depression_prob >= DEPRESSION_THRESHOLD
        label        = "Depressed" if is_depressed else "Not Depressed"

        # Confidence: distance from decision boundary, normalised to [0, 1]
        confidence = float(min(
            abs(depression_prob - DEPRESSION_THRESHOLD)
            / max(DEPRESSION_THRESHOLD, 1.0 - DEPRESSION_THRESHOLD),
            1.0,
        ))

        inference_ms = int((time.perf_counter() - t0) * 1000)

        return {
            "label":             label,
            "confidence":        round(confidence, 4),
            "inference_time_ms": inference_ms,
            # ── Legacy fields for frontend backward compat ──
            "prediction":  label,
            "probability": round(float(depression_prob), 4),
            "n_chunks":    len(chunks),
        }


# ──────────────────────────────────────────────────────────────
# 3.  FASTAPI WEB ENDPOINT
#     Single POST /predict  — accepts multipart/form-data (file)
#     or raw bytes body (application/octet-stream / audio/*).
#     Returns JSON matching { label, confidence, inference_time_ms }
# ──────────────────────────────────────────────────────────────
@app.function(image=image)
@modal.asgi_app()
def web() -> "fastapi.FastAPI":
    """
    Exposes a FastAPI ASGI app.  Modal routes HTTPS → this function.
    The WavLMPredictor container pool is separate (GPU); this function
    runs on a CPU worker and fans out .predict.remote() calls to GPU.
    """
    import fastapi
    from fastapi import File, UploadFile, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse

    api = fastapi.FastAPI(title="Lumen WavLM API", version="1.0.0")

    # Allow the React frontend origin; tighten before prod if needed
    api.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["POST", "GET", "OPTIONS"],
        allow_headers=["*"],
    )

    predictor = WavLMPredictor()

    # ------------------------------------------------------------------
    # Health check — frontend can poll this to detect cold-start state
    # (with keep_warm=1 this should return instantly)
    # ------------------------------------------------------------------
    @api.get("/api/health")
    async def health():
        return {"status": "ok", "model": HF_REPO_ID}

    # ------------------------------------------------------------------
    # Main inference endpoint
    # Accepts two request styles so the existing React VoiceAssessment
    # component works without any changes (it sends multipart/form-data
    # with field name "file"):
    #
    #   1. multipart/form-data   → file field  (browser upload / blob)
    #   2. raw body              → audio bytes  (curl / programmatic)
    # ------------------------------------------------------------------
    @api.post("/api/predict")
    async def predict(
        request: Request,
        file: UploadFile | None = File(default=None),
    ):
        try:
            content_type = "audio/wav"

            if file is not None:
                # Style 1: multipart upload (existing frontend sends this)
                audio_bytes  = await file.read()
                content_type = file.content_type or "audio/wav"
            else:
                # Style 2: raw body bytes
                audio_bytes  = await request.body()
                content_type = request.headers.get("content-type", "audio/wav")

            if not audio_bytes:
                return JSONResponse(
                    {"detail": "No audio data received."},
                    status_code=422,
                )

            result = predictor.predict.remote(audio_bytes, content_type)
            return JSONResponse(result)

        except Exception as exc:
            return JSONResponse(
                {"detail": str(exc)},
                status_code=500,
            )

    return api
